import java.util.Scanner;

public class  numGenerator  {
    public int generate(){
    Scanner sc= new Scanner(System.in);
    System.out.println("enter a number");
    int num=sc.nextInt();
    return num;
}
}
