public class doIntegerBasedRounding {
    public static void main (String args[]){
        arrayGenerator generator=new arrayGenerator();
        int arr[]=generator.generate();
        numGenerator gen=new numGenerator();
        int num=gen.generate();
        for (int i = 0; i < arr.length; i++) {
         
        }
    }
}
